const { 
    SlashCommandBuilder, 
    userMention, 
    MessageFlags, 
    ContainerBuilder, 
    MediaGalleryBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder 
} = require('discord.js');
const Promotion = require('../schemas/promotion');

async function generatePromotionId() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let id;
    while (true) {
        id = '#' + Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
        const exists = await Promotion.findOne({ promotionId: id });
        if (!exists) break;
    }
    return id;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('promotion')
        .setDescription('Promotion system')
        .addSubcommand(sub =>
            sub.setName('issue')
               .setDescription('Issue a promotion')
               .addUserOption(o => o.setName('user').setDescription('Staff member').setRequired(true))
               .addRoleOption(o => o.setName('new-rank').setDescription('New rank').setRequired(true))
               .addStringOption(o => o.setName('reason').setDescription('Reason for promotion').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('void')
               .setDescription('Void a promotion')
               .addStringOption(o => o.setName('id').setDescription('Promotion ID').setRequired(true))
        ),

    run: async ({ interaction }) => {
        const allowedRoles = [
            'ALLOWED_ROLE_ID',
            'ALLOWED_ROLE_ID',
            'ALLOWED_ROLE_ID',
        ];

        const member = interaction.member || await interaction.guild.members.fetch(interaction.user.id);
        const hasRole = member.roles.cache.some(role => allowedRoles.includes(role.id));
        if (!hasRole) return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });

        const sub = interaction.options.getSubcommand();

        try {
            if (sub === 'issue') {
                const user = interaction.options.getUser('user');
                const newRank = interaction.options.getRole('new-rank');
                const reason = interaction.options.getString('reason');
                const promotionId = await generatePromotionId();

                const promotion = await Promotion.create({
                    userId: user.id,
                    issuedBy: interaction.user.id,
                    newRankId: newRank.id,
                    reason,
                    promotionId
                });

                const banner = 'bannerurl';
                const footer = 'footerurl';

                const container = new ContainerBuilder().setAccentColor(0xf6ffa2);

                container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems([{ media: { url: banner } }]));

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## Staff Promotion\nThis user has been given a promotion by the HR team!`
                    ),
                    new TextDisplayBuilder().setContent(`**Staff Username** \`-\` ${userMention(user.id)}`)
                );

                container.addSeparatorComponents(new SeparatorBuilder());

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**New Rank** \`-\` ${newRank.name}`)
                );
                container.addSeparatorComponents(new SeparatorBuilder());

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Reason** \`-\` ${reason}`)
                );
                container.addSeparatorComponents(new SeparatorBuilder());

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Issued by** \`-\` <@${interaction.user.id}>`)
                );

                container.addSeparatorComponents(new SeparatorBuilder());

                                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Promotion ID** \`-\` ${promotionId}`)
                );

                container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems([{ media: { url: footer } }]));

                const channelid = 'CHANNEL_ID'
                    const ch = await interaction.client.channels.fetch(channelid)
                    await ch.send({ flags: MessageFlags.IsComponentsV2, components: [container], allowedMentions: { parse: [] } });

                return interaction.reply({ content: `Successfully promoted **@${user.username}**.\nID: \`${promotionId}\``, ephemeral: true });
            }

            if (sub === 'void') {
                const id = interaction.options.getString('id').toUpperCase();
                const deleted = await Promotion.findOneAndDelete({ promotionId: id });

                if (!deleted) {
                    return interaction.reply({ content: `No promotion found with ID \`${id}\`.`, ephemeral: true });
                }

                return interaction.reply({ content: `Promotion \`${id}\` has been **voided**.`, ephemeral: true });
            }

        } catch (error) {
            console.error("Error in /promotion command:", error);
            if (!interaction.replied) return interaction.reply({ content: "An error occurred while processing your request.", ephemeral: true });
        }
    }
};
