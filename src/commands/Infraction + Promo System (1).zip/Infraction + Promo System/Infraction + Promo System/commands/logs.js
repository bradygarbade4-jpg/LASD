const { SlashCommandBuilder, EmbedBuilder, userMention, ActionRowBuilder } = require('discord.js');
const Infraction = require('../schemas/infraction');
const Promotion = require('../schemas/promotion');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('logs')
        .setDescription('View logs of a user promotions or infraction.')
        .addUserOption(option => 
            option.setName('user')
                  .setDescription('Username to view logs of')
                  .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('type')
                  .setDescription('Type of log to view')
                  .setRequired(true)
                  .addChoices(
                      { name: 'Promotions', value: 'promotions' },
                      { name: 'Infractions', value: 'infractions' }
                  )
        ),

    run: async ({ interaction }) => {
            const allowedRoles = [
   'ALLOWED_ROLE_ID',
   'ALLOWED_ROLE_ID',
   'ALLOWED_ROLE_ID',
   ]

        if (!interaction.member.roles.cache.some(role => allowedRoles.includes(role.id))) {
            return interaction.reply({
                content: "You don't have permission to use this command.",
                ephemeral: true
            });
        }

        const user = interaction.options.getUser('user');
        const type = interaction.options.getString('type');

        let logs;
        if (type === 'infractions') {
            logs = await Infraction.find({ userId: user.id }).sort({ date: 1 });
        } else if (type === 'promotions') {
            logs = await Promotion.find({ userId: user.id }).sort({ date: 1 });
        } else {
            return interaction.reply({ content: "Invalid log type.", ephemeral: true });
        }

        if (!logs.length) {
            return interaction.reply({ content: `No ${type} found for ${user.username}.`, ephemeral: true });
        }

        const embedBatches = [];
        let currentBatch = [];

        for (let i = 0; i < logs.length; i++) {
            const log = logs[i];

            let embed;
            if (type === 'infractions') {
                embed = new EmbedBuilder()
                    .setTitle(`Infraction Log #${i + 1}`)
                    .addFields(
                        { name: 'User', value: `${userMention(log.userId)}`, inline: true },
                        { name: 'Issued by', value: `<@${log.issuedBy}>`, inline: true },
                        { name: 'Reason', value: log.reason },
                        { name: 'Punishment', value: log.punishment }
                    )
                    .setColor('#2d2d31');
            } else {
                embed = new EmbedBuilder()
                    .setTitle(`Promotion Log #${i + 1}`)
                    .addFields(
                        { name: 'User', value: `${userMention(log.userId)}`, inline: true },
                        { name: 'Issued by', value: `<@${log.issuedBy}>`, inline: true },
                        { name: 'Reason', value: log.reason },
                        { name: 'New Rank', value: `<@&${log.newRankId}>` }
                    )
                    .setColor('#2d2d31');
            }

            currentBatch.push(embed);

            if (currentBatch.length === 10 || i === logs.length - 1) {
                embedBatches.push(currentBatch);
                currentBatch = [];
            }
        }

        for (let batch of embedBatches) {
            await interaction.reply({ embeds: batch, ephemeral: true });
        }

        if (embedBatches.length === 0) {
            await interaction.followUp({ content: `No ${type} found for ${user.username}.`, ephemeral: true });
        } else if (embedBatches.length === 1) {
            await interaction.followUp({ content: `Showing ${logs.length} ${type} for ${user.username}.`, ephemeral: true });
        }
    }
};
